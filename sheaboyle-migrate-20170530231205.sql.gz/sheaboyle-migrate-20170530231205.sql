# WordPress MySQL database migration
#
# Generated: Tuesday 30. May 2017 23:12 UTC
# Hostname: localhost
# Database: `sheaboyle`
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_comments`
#

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=874 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://shea-boyle.com', 'yes'),
(2, 'home', 'http://shea-boyle.com', 'yes'),
(3, 'blogname', 'Panish Shea &amp; Boyle LLP', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'garrett@1point21interactive.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '15', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:91:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=4&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:8:{i:0;s:29:"gravityforms/gravityforms.php";i:1;s:41:"acf-theme-code-pro/acf_theme_code_pro.php";i:2;s:34:"advanced-custom-fields-pro/acf.php";i:3;s:19:"bugherd/bugherd.php";i:4;s:38:"post-duplicator/m4c-postduplicator.php";i:5;s:37:"user-role-editor/user-role-editor.php";i:6;s:24:"wordpress-seo/wp-seo.php";i:7;s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'psb', 'yes'),
(41, 'stylesheet', 'psb', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:0:{}', 'yes'),
(80, 'widget_rss', 'a:0:{}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(84, 'page_on_front', '4', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:69:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:14:"ure_edit_roles";b:1;s:16:"ure_create_roles";b:1;s:16:"ure_delete_roles";b:1;s:23:"ure_create_capabilities";b:1;s:23:"ure_delete_capabilities";b:1;s:18:"ure_manage_options";b:1;s:15:"ure_reset_roles";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:35:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-posts', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:6:"number";i:8;s:9:"show_date";b:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'sidebars_widgets', 'a:4:{s:19:"wp_inactive_widgets";a:0:{}s:7:"sidebar";a:1:{i:0;s:14:"recent-posts-2";}s:11:"sidebar-cat";a:1:{i:0;s:12:"categories-2";}s:13:"array_version";i:3;}', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(101, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(104, 'cron', 'a:5:{i:1496211040;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1496254266;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1496254946;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1496259905;a:1:{s:17:"gravityforms_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(105, 'theme_mods_twentyseventeen', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1493316981;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(118, 'can_compress_scripts', '1', 'no'),
(135, 'current_theme', 'PSB Aviation', 'yes'),
(136, 'theme_mods_psb', 'a:3:{i:0;b:0;s:18:"custom_css_post_id";i:-1;s:18:"nav_menu_locations";a:1:{s:9:"main_menu";i:2;}}', 'yes'),
(137, 'theme_switched', '', 'yes'),
(140, 'recently_activated', 'a:1:{s:56:"password-protect-plugin-for-wordpress/wp_passprotect.php";i:1495818821;}', 'yes'),
(180, 'WPLANG', '', 'yes'),
(183, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(309, 'widget_gform_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(310, 'rg_form_version', '2.2.2', 'yes'),
(316, 'rg_gforms_key', '1d2171a4356ea219c66df9655cf2d5e3', 'yes'),
(317, 'rg_gforms_disable_css', '1', 'yes'),
(318, 'rg_gforms_enable_html5', '0', 'yes'),
(319, 'gform_enable_noconflict', '0', 'yes'),
(320, 'rg_gforms_enable_akismet', '', 'yes'),
(321, 'rg_gforms_captcha_public_key', '', 'yes'),
(322, 'rg_gforms_captcha_private_key', '', 'yes'),
(323, 'rg_gforms_currency', 'USD', 'yes'),
(324, 'rg_gforms_message', '<!--GFM--><!-- unregistered copy notice -->\r\n<div style=\\"margin:10px 0 10px 0; border-bottom:1px solid #D7D7D7; text-align:center; display:block!important; visibility: visible!important; min-width:880px;\\"><a href=\\"http://www.gravityforms.com/purchase-gravity-forms/\\" target=\\"_blank\\" style=\\"width:880px; height:90px;\\"><img src=\\"https://gravityforms.s3.amazonaws.com/banners/gravity-forms-unregistered-2.png\\" width=\\"880\\" height=\\"90\\" alt=\\"Unlicensed Copy. Please purchase a Gravity Forms license\\" title=\\"Unlicensed Copy\\" /></a></div>\r\n<!-- end notice -->', 'yes'),
(326, 'gravityformsaddon_gravityformswebapi_version', '1.0', 'yes'),
(327, 'gf_is_upgrading', '0', 'yes'),
(328, 'gf_previous_db_version', '0', 'yes'),
(329, 'gf_db_version', '2.2.2', 'yes'),
(492, 'mtphr_post_duplicator_settings', '', 'yes'),
(499, 'category_children', 'a:0:{}', 'yes'),
(716, 'page_for_posts', '21', 'yes'),
(784, 'upload_path', '', 'yes'),
(785, 'upload_url_path', '', 'yes'),
(828, 'bugherd_options', 'a:4:{s:24:"bugherd_integration_code";s:22:"v4gcgcskidgnxjury9qm8g";s:11:"user_levels";a:1:{i:0;s:12:"unregistered";}s:12:"enable_admin";s:2:"no";s:5:"sites";a:0:{}}', 'yes'),
(838, 'acf_version', '5.5.14', 'yes'),
(839, 'acf_pro_license', 'YToyOntzOjM6ImtleSI7czo3MjoiYjNKa1pYSmZhV1E5TXpNeU9ETjhkSGx3WlQxa1pYWmxiRzl3WlhKOFpHRjBaVDB5TURFMExUQTNMVEEzSURJeE9qSTRPak0yIjtzOjM6InVybCI7czoyMToiaHR0cDovL3NoZWEtYm95bGUuY29tIjt9', 'yes'),
(840, 'dd9b23a13775ccc12b5389d301f8ef5d', 'a:2:{s:7:"timeout";i:1496195121;s:5:"value";s:5592:"{"new_version":"2.0.0","stable_version":"2.0.0","name":"ACF Theme Code Pro","slug":"acf_theme_code_pro","url":"https:\\/\\/hookturn.io\\/downloads\\/acf-theme-code-pro\\/?changelog=1","last_updated":"2017-04-24 20:41:18","homepage":"https:\\/\\/hookturn.io\\/downloads\\/acf-theme-code-pro\\/","package":"","download_link":"","sections":{"description":"<p>Save time &amp; automatically generate the code required to implement Advanced Custom Fields in your themes!<br \\/>\\nACF Theme Code Pro is a premium add-on\\u00a0for the awesome\\u00a0<a href=\\"https:\\/\\/www.advancedcustomfields.com\\/pro\\/\\" target=\\"_blank\\" rel=\\"nofollow noopener noreferrer\\">Advanced Custom Fields Pro<\\/a>\\u00a0WordPress plugin.<\\/p>\\n<p>[ecquote]<\\/p>\\n<p>Whenever you publish, edit or update an ACF Field Group, the code required to implement your unique custom fields is conveniently displayed in a <strong>Theme Code<\\/strong> section right below the Field Group settings.<\\/p>\\n<p>Features<\\/p>\\n<ul>\\n<li>Clipboard icons to easily copy code blocks into your theme<\\/li>\\n<li>Field names and variables are automatically updated<\\/li>\\n<li>Code generated is based on the official ACF documentation<\\/li>\\n<li>Great for offline ACF documentation<\\/li>\\n<\\/ul>\\n<p>ACF Theme Code Pro generates code for the premium ACF fields:<\\/p>\\n<ul class=\\"two-up\\">\\n<li>Flexible content field<\\/li>\\n<li>Repeater field<\\/li>\\n<li>Gallery field<\\/li>\\n<li>Clone field<\\/li>\\n<\\/ul>\\n<p>ACF Theme Code Pro generates code for these 3rd Party fields:<\\/p>\\n<ul class=\\"two-up\\">\\n<li>Font Awesome field<\\/li>\\n<li>Google font selector field<\\/li>\\n<li>Image crop field<\\/li>\\n<li>Markdown field<\\/li>\\n<li>Nav Menu field<\\/li>\\n<li>RGBA Colour field<\\/li>\\n<li>Sidebar Selector field<\\/li>\\n<li>Smart Button field<\\/li>\\n<li>Table field<\\/li>\\n<li>TablePress field<\\/li>\\n<li>Address Field<\\/li>\\n<li>Number Slider Field<\\/li>\\n<li>Post Type Select Field<\\/li>\\n<li>Code Field<\\/li>\\n<li>Link Field<\\/li>\\n<li>Link Picker Field<\\/li>\\n<li>YouTube Picker Field<\\/li>\\n<\\/ul>\\n<p>ACF Theme Code Pro generates the code for all standard ACF fields:<\\/p>\\n<ul class=\\"two-up\\">\\n<li>Text<\\/li>\\n<li>Text Area<\\/li>\\n<li>Number<\\/li>\\n<li>Email<\\/li>\\n<li>Password<\\/li>\\n<li>WYSIWYG<\\/li>\\n<li>File<\\/li>\\n<li>Image<\\/li>\\n<li>Select<\\/li>\\n<li>Checkbox<\\/li>\\n<li>Radio<\\/li>\\n<li>True \\/ False<\\/li>\\n<li>User<\\/li>\\n<li>Google Map<\\/li>\\n<li>Date Picker<\\/li>\\n<li>Colour Picker<\\/li>\\n<li>Page Link<\\/li>\\n<li>Post Object<\\/li>\\n<li>Relationship<\\/li>\\n<li>Taxonomy<\\/li>\\n<\\/ul>\\n<p>New in Version 2 : Location Rule Support<\\/p>\\n<p>ACF Theme Code Pro can generate code for multiple location rules on each field group, you\\u2019re using ACF Pro this includes locations\\u00a0like <strong>Options<\\/strong>, <strong>Users<\\/strong>, <strong>Widgets<\\/strong>, <strong>Comments<\\/strong>, <strong>Terms<\\/strong> and <strong>Attachments.<\\/strong><br \\/>\\nWorks best with:<\\/p>\\n<ul>\\n<li>Advanced Custom Fields\\u00a0Pro v5.5 or higher<\\/li>\\n<li>Advanced Custom Fields (Free) v4.4 or v5.0<\\/li>\\n<li>WordPress 4.7 or higher<\\/li>\\n<\\/ul>\\n<p>Current Pro Version<\\/p>\\n<ul>\\n<li>Version 2.0.0\\u00a0released in April\\u00a02017<\\/li>\\n<\\/ul>\\n<p>If you\'d like to \'try before you buy\' you can\\u00a0<a href=\\"https:\\/\\/wordpress.org\\/plugins\\/acf-theme-code\\/\\" target=\\"_blank\\" rel=\\"noopener noreferrer\\">check out our free version<\\/a> on WordPress.org. Our free version has basic support for the free version of Advanced Custom Fields.<br \\/>\\nThe ACF Theme Code Plugin was created by:<br \\/>\\nAaron &amp; Ben, two WordPress developers based in Melbourne, Australia.<\\/p>\\n<p>[plugin_authors_block]<\\/p>\\n","changelog":"<p>2.0.0<\\/p>\\n<ul>\\n<li>Core : Theme Code Pro now generates code based on your location rules!<\\/li>\\n<li>Core : Theme Code Pro now supports all official ACF Add ons!<\\/li>\\n<li>Core : Theme Code Pro now works when ACF Pro is included in a theme!<\\/li>\\n<li>Location Supported : Options Page<\\/li>\\n<li>Location Supported : Widget<\\/li>\\n<li>Location Supported : Comment<\\/li>\\n<li>Location Supported : Taxonomy Term<\\/li>\\n<li>Location Supported : User<\\/li>\\n<li>Location Supported : Attachment<\\/li>\\n<li>Add-on supported : Options Page<\\/li>\\n<li>Add on supported : Repeater Field<\\/li>\\n<li>Add on supported : Gallery Field<\\/li>\\n<li>Add on supported : Flexible Content Field<\\/li>\\n<li>Fix : Minor bug in file field example link markup<\\/li>\\n<li>Fix : Support for Quicklinks feature within locations<\\/li>\\n<\\/ul>\\n<p>1.2.0<\\/p>\\n<ul>\\n<li>Field : Clone - major improvements to the clone field code output<\\/li>\\n<li>New Field Supported : Address Field<\\/li>\\n<li>New Field Supported : Number Slider Field<\\/li>\\n<li>New Field Supported : Post Type Select Field<\\/li>\\n<li>New Field Supported : Code Field<\\/li>\\n<li>New Field Supported : Link Field<\\/li>\\n<li>New Field Supported : Link Picker Field<\\/li>\\n<li>New Field Supported : YouTube Picker Field<\\/li>\\n<li>Core : Special characters now removed from variable names<\\/li>\\n<li>Fix : Compatibility with CPTUI Pro Plugin<\\/li>\\n<\\/ul>\\n<p>1.1.0<\\/p>\\n<ul>\\n<li>Core: Quicklinks feature with anchor links to the relevant theme code block<\\/li>\\n<li>Core: Notice updates &amp; various bug fixes<\\/li>\\n<li>Core: Plugin options screen moved under Settings<\\/li>\\n<\\/ul>\\n<p>1.0.3<\\/p>\\n<ul>\\n<li>Fix: Use the_sub_field method for nested File fields with return format URL<\\/li>\\n<\\/ul>\\n<p>1.0.2<\\/p>\\n<ul>\\n<li>Field: Fix for Post Object when using ACF 4<\\/li>\\n<li>Core: Various internal code improvements<\\/li>\\n<\\/ul>\\n"},"banners":{"high":"","low":""}}";}', 'yes'),
(844, 'hookturn_acftcp_license_key', '631dfe9835ead92c781c66a4654e1c79', 'yes'),
(847, '2057dd01900c5459c5051c796e8d92e2', 'a:2:{s:7:"timeout";i:1496195165;s:5:"value";s:5970:"{"new_version":"2.0.0","stable_version":"2.0.0","name":"ACF Theme Code Pro","slug":"acf_theme_code_pro","url":"https:\\/\\/hookturn.io\\/downloads\\/acf-theme-code-pro\\/?changelog=1","last_updated":"2017-04-24 20:41:18","homepage":"https:\\/\\/hookturn.io\\/downloads\\/acf-theme-code-pro\\/","package":"https:\\/\\/hookturn.io\\/edd-sl\\/package_download\\/MTQ5NjMwNjc2Mzo2MzFkZmU5ODM1ZWFkOTJjNzgxYzY2YTQ2NTRlMWM3OToxNTpjZGU5YjFkN2RiODlhOTNkOTFlYjY0OGE5YTVjZjdkNjpodHRwQC8vc2hlYS1ib3lsZS5jb206MA==","download_link":"https:\\/\\/hookturn.io\\/edd-sl\\/package_download\\/MTQ5NjMwNjc2Mzo2MzFkZmU5ODM1ZWFkOTJjNzgxYzY2YTQ2NTRlMWM3OToxNTpjZGU5YjFkN2RiODlhOTNkOTFlYjY0OGE5YTVjZjdkNjpodHRwQC8vc2hlYS1ib3lsZS5jb206MA==","sections":{"description":"<p>Save time &amp; automatically generate the code required to implement Advanced Custom Fields in your themes!<br \\/>\\nACF Theme Code Pro is a premium add-on\\u00a0for the awesome\\u00a0<a href=\\"https:\\/\\/www.advancedcustomfields.com\\/pro\\/\\" target=\\"_blank\\" rel=\\"nofollow noopener noreferrer\\">Advanced Custom Fields Pro<\\/a>\\u00a0WordPress plugin.<\\/p>\\n<p>[ecquote]<\\/p>\\n<p>Whenever you publish, edit or update an ACF Field Group, the code required to implement your unique custom fields is conveniently displayed in a <strong>Theme Code<\\/strong> section right below the Field Group settings.<\\/p>\\n<p>Features<\\/p>\\n<ul>\\n<li>Clipboard icons to easily copy code blocks into your theme<\\/li>\\n<li>Field names and variables are automatically updated<\\/li>\\n<li>Code generated is based on the official ACF documentation<\\/li>\\n<li>Great for offline ACF documentation<\\/li>\\n<\\/ul>\\n<p>ACF Theme Code Pro generates code for the premium ACF fields:<\\/p>\\n<ul class=\\"two-up\\">\\n<li>Flexible content field<\\/li>\\n<li>Repeater field<\\/li>\\n<li>Gallery field<\\/li>\\n<li>Clone field<\\/li>\\n<\\/ul>\\n<p>ACF Theme Code Pro generates code for these 3rd Party fields:<\\/p>\\n<ul class=\\"two-up\\">\\n<li>Font Awesome field<\\/li>\\n<li>Google font selector field<\\/li>\\n<li>Image crop field<\\/li>\\n<li>Markdown field<\\/li>\\n<li>Nav Menu field<\\/li>\\n<li>RGBA Colour field<\\/li>\\n<li>Sidebar Selector field<\\/li>\\n<li>Smart Button field<\\/li>\\n<li>Table field<\\/li>\\n<li>TablePress field<\\/li>\\n<li>Address Field<\\/li>\\n<li>Number Slider Field<\\/li>\\n<li>Post Type Select Field<\\/li>\\n<li>Code Field<\\/li>\\n<li>Link Field<\\/li>\\n<li>Link Picker Field<\\/li>\\n<li>YouTube Picker Field<\\/li>\\n<\\/ul>\\n<p>ACF Theme Code Pro generates the code for all standard ACF fields:<\\/p>\\n<ul class=\\"two-up\\">\\n<li>Text<\\/li>\\n<li>Text Area<\\/li>\\n<li>Number<\\/li>\\n<li>Email<\\/li>\\n<li>Password<\\/li>\\n<li>WYSIWYG<\\/li>\\n<li>File<\\/li>\\n<li>Image<\\/li>\\n<li>Select<\\/li>\\n<li>Checkbox<\\/li>\\n<li>Radio<\\/li>\\n<li>True \\/ False<\\/li>\\n<li>User<\\/li>\\n<li>Google Map<\\/li>\\n<li>Date Picker<\\/li>\\n<li>Colour Picker<\\/li>\\n<li>Page Link<\\/li>\\n<li>Post Object<\\/li>\\n<li>Relationship<\\/li>\\n<li>Taxonomy<\\/li>\\n<\\/ul>\\n<p>New in Version 2 : Location Rule Support<\\/p>\\n<p>ACF Theme Code Pro can generate code for multiple location rules on each field group, you\\u2019re using ACF Pro this includes locations\\u00a0like <strong>Options<\\/strong>, <strong>Users<\\/strong>, <strong>Widgets<\\/strong>, <strong>Comments<\\/strong>, <strong>Terms<\\/strong> and <strong>Attachments.<\\/strong><br \\/>\\nWorks best with:<\\/p>\\n<ul>\\n<li>Advanced Custom Fields\\u00a0Pro v5.5 or higher<\\/li>\\n<li>Advanced Custom Fields (Free) v4.4 or v5.0<\\/li>\\n<li>WordPress 4.7 or higher<\\/li>\\n<\\/ul>\\n<p>Current Pro Version<\\/p>\\n<ul>\\n<li>Version 2.0.0\\u00a0released in April\\u00a02017<\\/li>\\n<\\/ul>\\n<p>If you\'d like to \'try before you buy\' you can\\u00a0<a href=\\"https:\\/\\/wordpress.org\\/plugins\\/acf-theme-code\\/\\" target=\\"_blank\\" rel=\\"noopener noreferrer\\">check out our free version<\\/a> on WordPress.org. Our free version has basic support for the free version of Advanced Custom Fields.<br \\/>\\nThe ACF Theme Code Plugin was created by:<br \\/>\\nAaron &amp; Ben, two WordPress developers based in Melbourne, Australia.<\\/p>\\n<p>[plugin_authors_block]<\\/p>\\n","changelog":"<p>2.0.0<\\/p>\\n<ul>\\n<li>Core : Theme Code Pro now generates code based on your location rules!<\\/li>\\n<li>Core : Theme Code Pro now supports all official ACF Add ons!<\\/li>\\n<li>Core : Theme Code Pro now works when ACF Pro is included in a theme!<\\/li>\\n<li>Location Supported : Options Page<\\/li>\\n<li>Location Supported : Widget<\\/li>\\n<li>Location Supported : Comment<\\/li>\\n<li>Location Supported : Taxonomy Term<\\/li>\\n<li>Location Supported : User<\\/li>\\n<li>Location Supported : Attachment<\\/li>\\n<li>Add-on supported : Options Page<\\/li>\\n<li>Add on supported : Repeater Field<\\/li>\\n<li>Add on supported : Gallery Field<\\/li>\\n<li>Add on supported : Flexible Content Field<\\/li>\\n<li>Fix : Minor bug in file field example link markup<\\/li>\\n<li>Fix : Support for Quicklinks feature within locations<\\/li>\\n<\\/ul>\\n<p>1.2.0<\\/p>\\n<ul>\\n<li>Field : Clone - major improvements to the clone field code output<\\/li>\\n<li>New Field Supported : Address Field<\\/li>\\n<li>New Field Supported : Number Slider Field<\\/li>\\n<li>New Field Supported : Post Type Select Field<\\/li>\\n<li>New Field Supported : Code Field<\\/li>\\n<li>New Field Supported : Link Field<\\/li>\\n<li>New Field Supported : Link Picker Field<\\/li>\\n<li>New Field Supported : YouTube Picker Field<\\/li>\\n<li>Core : Special characters now removed from variable names<\\/li>\\n<li>Fix : Compatibility with CPTUI Pro Plugin<\\/li>\\n<\\/ul>\\n<p>1.1.0<\\/p>\\n<ul>\\n<li>Core: Quicklinks feature with anchor links to the relevant theme code block<\\/li>\\n<li>Core: Notice updates &amp; various bug fixes<\\/li>\\n<li>Core: Plugin options screen moved under Settings<\\/li>\\n<\\/ul>\\n<p>1.0.3<\\/p>\\n<ul>\\n<li>Fix: Use the_sub_field method for nested File fields with return format URL<\\/li>\\n<\\/ul>\\n<p>1.0.2<\\/p>\\n<ul>\\n<li>Field: Fix for Post Object when using ACF 4<\\/li>\\n<li>Core: Various internal code improvements<\\/li>\\n<\\/ul>\\n"},"banners":{"high":"","low":""}}";}', 'yes'),
(850, 'user_role_editor', 'a:1:{s:11:"ure_version";s:4:"4.33";}', 'yes'),
(851, 'wp_backup_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'no'),
(852, 'ure_tasks_queue', 'a:0:{}', 'yes'),
(853, 'wpseo', 'a:24:{s:14:"blocking_files";a:0:{}s:15:"ms_defaults_set";b:0;s:7:"version";s:3:"4.8";s:12:"company_logo";s:0:"";s:12:"company_name";s:0:"";s:17:"company_or_person";s:0:"";s:20:"disableadvanced_meta";b:1;s:19:"onpage_indexability";b:1;s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:11:"person_name";s:0:"";s:12:"website_name";s:0:"";s:22:"alternate_website_name";s:0:"";s:12:"yandexverify";s:0:"";s:9:"site_type";s:0:"";s:20:"has_multiple_authors";b:0;s:16:"environment_type";s:0:"";s:23:"content_analysis_active";b:1;s:23:"keyword_analysis_active";b:1;s:20:"enable_setting_pages";b:1;s:21:"enable_admin_bar_menu";b:1;s:26:"enable_cornerstone_content";b:1;s:22:"show_onboarding_notice";b:1;s:18:"first_activated_on";b:0;}', 'yes'),
(854, 'wpseo_permalinks', 'a:9:{s:15:"cleanpermalinks";b:0;s:24:"cleanpermalink-extravars";s:0:"";s:29:"cleanpermalink-googlecampaign";b:0;s:31:"cleanpermalink-googlesitesearch";b:0;s:15:"cleanreplytocom";b:0;s:10:"cleanslugs";b:1;s:18:"redirectattachment";b:0;s:17:"stripcategorybase";b:0;s:13:"trailingslash";b:0;}', 'yes'),
(855, 'wpseo_titles', 'a:54:{s:10:"title_test";i:0;s:17:"forcerewritetitle";b:1;s:9:"separator";s:7:"sc-dash";s:5:"noodp";b:0;s:15:"usemetakeywords";b:0;s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:41:"%%name%%, Author at %%sitename%% %%page%%";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:63:"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:15:"title-404-wpseo";s:35:"Page not found %%sep%% %%sitename%%";s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:18:"metakey-home-wpseo";s:0:"";s:20:"metakey-author-wpseo";s:0:"";s:22:"noindex-subpages-wpseo";b:0;s:20:"noindex-author-wpseo";b:0;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:19:"disable-post_format";b:0;s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"metakey-post";s:0:"";s:12:"noindex-post";b:0;s:13:"showdate-post";b:0;s:16:"hideeditbox-post";b:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"metakey-page";s:0:"";s:12:"noindex-page";b:0;s:13:"showdate-page";b:0;s:16:"hideeditbox-page";b:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"metakey-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:19:"showdate-attachment";b:0;s:22:"hideeditbox-attachment";b:0;s:18:"title-tax-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:20:"metakey-tax-category";s:0:"";s:24:"hideeditbox-tax-category";b:0;s:20:"noindex-tax-category";b:0;s:18:"title-tax-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:20:"metakey-tax-post_tag";s:0:"";s:24:"hideeditbox-tax-post_tag";b:0;s:20:"noindex-tax-post_tag";b:0;s:21:"title-tax-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:23:"metakey-tax-post_format";s:0:"";s:27:"hideeditbox-tax-post_format";b:0;s:23:"noindex-tax-post_format";b:1;}', 'yes'),
(856, 'wpseo_social', 'a:20:{s:9:"fb_admins";a:0:{}s:12:"fbconnectkey";s:32:"90ff7be6c4b19c3f915c4a78972c3bc8";s:13:"facebook_site";s:0:"";s:13:"instagram_url";s:0:"";s:12:"linkedin_url";s:0:"";s:11:"myspace_url";s:0:"";s:16:"og_default_image";s:0:"";s:18:"og_frontpage_title";s:0:"";s:17:"og_frontpage_desc";s:0:"";s:18:"og_frontpage_image";s:0:"";s:9:"opengraph";b:1;s:13:"pinterest_url";s:0:"";s:15:"pinterestverify";s:0:"";s:14:"plus-publisher";s:0:"";s:7:"twitter";b:1;s:12:"twitter_site";s:0:"";s:17:"twitter_card_type";s:7:"summary";s:11:"youtube_url";s:0:"";s:15:"google_plus_url";s:0:"";s:10:"fbadminapp";s:0:"";}', 'yes'),
(857, 'wpseo_rss', 'a:2:{s:9:"rssbefore";s:0:"";s:8:"rssafter";s:53:"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.";}', 'yes'),
(858, 'wpseo_internallinks', 'a:10:{s:20:"breadcrumbs-404crumb";s:25:"Error 404: Page not found";s:23:"breadcrumbs-blog-remove";b:0;s:20:"breadcrumbs-boldlast";b:0;s:25:"breadcrumbs-archiveprefix";s:12:"Archives for";s:18:"breadcrumbs-enable";b:0;s:16:"breadcrumbs-home";s:4:"Home";s:18:"breadcrumbs-prefix";s:0:"";s:24:"breadcrumbs-searchprefix";s:16:"You searched for";s:15:"breadcrumbs-sep";s:7:"&raquo;";s:23:"post_types-post-maintax";i:0;}', 'yes'),
(859, 'wpseo_xml', 'a:16:{s:22:"disable_author_sitemap";b:1;s:22:"disable_author_noposts";b:1;s:16:"enablexmlsitemap";b:1;s:16:"entries-per-page";i:1000;s:14:"excluded-posts";s:0:"";s:38:"user_role-administrator-not_in_sitemap";b:0;s:31:"user_role-editor-not_in_sitemap";b:0;s:31:"user_role-author-not_in_sitemap";b:0;s:36:"user_role-contributor-not_in_sitemap";b:0;s:35:"user_role-subscriber-not_in_sitemap";b:0;s:30:"post_types-post-not_in_sitemap";b:0;s:30:"post_types-page-not_in_sitemap";b:0;s:36:"post_types-attachment-not_in_sitemap";b:1;s:34:"taxonomies-category-not_in_sitemap";b:0;s:34:"taxonomies-post_tag-not_in_sitemap";b:0;s:37:"taxonomies-post_format-not_in_sitemap";b:0;}', 'yes'),
(860, 'wpseo_flush_rewrite', '1', 'yes'),
(863, 'wpseo_sitemap_cache_validator_global', '6VAnm', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=255 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2, 4, '_edit_last', '1'),
(3, 4, '_wp_page_template', 'page-main.php'),
(4, 4, '_edit_lock', '1493669670:1'),
(12, 9, '_menu_item_type', 'post_type'),
(13, 9, '_menu_item_menu_item_parent', '0'),
(14, 9, '_menu_item_object_id', '4'),
(15, 9, '_menu_item_object', 'page'),
(16, 9, '_menu_item_target', ''),
(17, 9, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(18, 9, '_menu_item_xfn', ''),
(19, 9, '_menu_item_url', ''),
(20, 9, '_menu_item_orphaned', '1493670721'),
(21, 10, '_menu_item_type', 'post_type'),
(22, 10, '_menu_item_menu_item_parent', '0'),
(23, 10, '_menu_item_object_id', '4'),
(24, 10, '_menu_item_object', 'page'),
(25, 10, '_menu_item_target', ''),
(26, 10, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(27, 10, '_menu_item_xfn', ''),
(28, 10, '_menu_item_url', ''),
(29, 10, '_menu_item_orphaned', '1493670721'),
(30, 11, '_edit_last', '1'),
(31, 11, '_edit_lock', '1493670623:1'),
(32, 11, '_wp_page_template', 'default'),
(33, 13, '_edit_last', '1'),
(34, 13, '_edit_lock', '1495055174:1'),
(35, 13, '_wp_page_template', 'page-attorney.php'),
(36, 15, '_edit_last', '1'),
(37, 15, '_wp_page_template', 'page-caseresults.php'),
(38, 15, '_edit_lock', '1495144127:1'),
(39, 17, '_edit_last', '1'),
(40, 17, '_wp_page_template', 'default'),
(41, 17, '_edit_lock', '1493670698:1'),
(42, 19, '_edit_last', '1'),
(43, 19, '_edit_lock', '1495125504:1'),
(44, 19, '_wp_page_template', 'page-padirectory.php'),
(45, 21, '_edit_last', '1'),
(46, 21, '_edit_lock', '1495733033:1'),
(47, 21, '_wp_page_template', 'page-blog.php'),
(48, 23, '_edit_last', '1'),
(49, 23, '_edit_lock', '1495142726:1'),
(50, 23, '_wp_page_template', 'page-contact.php'),
(51, 25, '_menu_item_type', 'post_type'),
(52, 25, '_menu_item_menu_item_parent', '0'),
(53, 25, '_menu_item_object_id', '4'),
(54, 25, '_menu_item_object', 'page'),
(55, 25, '_menu_item_target', ''),
(56, 25, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(57, 25, '_menu_item_xfn', ''),
(58, 25, '_menu_item_url', ''),
(59, 25, '_menu_item_orphaned', '1493670879'),
(87, 29, '_menu_item_type', 'post_type'),
(88, 29, '_menu_item_menu_item_parent', '0'),
(89, 29, '_menu_item_object_id', '23'),
(90, 29, '_menu_item_object', 'page'),
(91, 29, '_menu_item_target', ''),
(92, 29, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(93, 29, '_menu_item_xfn', ''),
(94, 29, '_menu_item_url', ''),
(96, 30, '_menu_item_type', 'post_type'),
(97, 30, '_menu_item_menu_item_parent', '0'),
(98, 30, '_menu_item_object_id', '4'),
(99, 30, '_menu_item_object', 'page'),
(100, 30, '_menu_item_target', ''),
(101, 30, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(102, 30, '_menu_item_xfn', ''),
(103, 30, '_menu_item_url', ''),
(105, 31, '_menu_item_type', 'post_type'),
(106, 31, '_menu_item_menu_item_parent', '0'),
(107, 31, '_menu_item_object_id', '21'),
(108, 31, '_menu_item_object', 'page'),
(109, 31, '_menu_item_target', ''),
(110, 31, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(111, 31, '_menu_item_xfn', ''),
(112, 31, '_menu_item_url', ''),
(123, 33, '_menu_item_type', 'post_type'),
(124, 33, '_menu_item_menu_item_parent', '0'),
(125, 33, '_menu_item_object_id', '15'),
(126, 33, '_menu_item_object', 'page'),
(127, 33, '_menu_item_target', ''),
(128, 33, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(129, 33, '_menu_item_xfn', ''),
(130, 33, '_menu_item_url', ''),
(132, 34, '_menu_item_type', 'custom'),
(133, 34, '_menu_item_menu_item_parent', '0'),
(134, 34, '_menu_item_object_id', '34'),
(135, 34, '_menu_item_object', 'custom'),
(136, 34, '_menu_item_target', ''),
(137, 34, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(138, 34, '_menu_item_xfn', ''),
(139, 34, '_menu_item_url', ''),
(141, 35, '_menu_item_type', 'post_type'),
(142, 35, '_menu_item_menu_item_parent', '37'),
(143, 35, '_menu_item_object_id', '19'),
(144, 35, '_menu_item_object', 'page'),
(145, 35, '_menu_item_target', ''),
(146, 35, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(147, 35, '_menu_item_xfn', ''),
(148, 35, '_menu_item_url', ''),
(150, 36, '_menu_item_type', 'post_type') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(151, 36, '_menu_item_menu_item_parent', '34'),
(152, 36, '_menu_item_object_id', '13'),
(153, 36, '_menu_item_object', 'page'),
(154, 36, '_menu_item_target', ''),
(155, 36, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(156, 36, '_menu_item_xfn', ''),
(157, 36, '_menu_item_url', ''),
(159, 37, '_menu_item_type', 'custom'),
(160, 37, '_menu_item_menu_item_parent', '0'),
(161, 37, '_menu_item_object_id', '37'),
(162, 37, '_menu_item_object', 'custom'),
(163, 37, '_menu_item_target', ''),
(164, 37, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(165, 37, '_menu_item_xfn', ''),
(166, 37, '_menu_item_url', ''),
(168, 38, '_menu_item_type', 'post_type'),
(169, 38, '_menu_item_menu_item_parent', '0'),
(170, 38, '_menu_item_object_id', '17'),
(171, 38, '_menu_item_object', 'page'),
(172, 38, '_menu_item_target', ''),
(173, 38, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(174, 38, '_menu_item_xfn', ''),
(175, 38, '_menu_item_url', ''),
(176, 38, '_menu_item_orphaned', '1493671077'),
(177, 39, '_menu_item_type', 'post_type'),
(178, 39, '_menu_item_menu_item_parent', '0'),
(179, 39, '_menu_item_object_id', '11'),
(180, 39, '_menu_item_object', 'page'),
(181, 39, '_menu_item_target', ''),
(182, 39, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(183, 39, '_menu_item_xfn', ''),
(184, 39, '_menu_item_url', ''),
(185, 39, '_menu_item_orphaned', '1493671077'),
(186, 40, '_menu_item_type', 'post_type'),
(187, 40, '_menu_item_menu_item_parent', '37'),
(188, 40, '_menu_item_object_id', '17'),
(189, 40, '_menu_item_object', 'page'),
(190, 40, '_menu_item_target', ''),
(191, 40, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(192, 40, '_menu_item_xfn', ''),
(193, 40, '_menu_item_url', ''),
(194, 41, '_menu_item_type', 'custom'),
(195, 41, '_menu_item_menu_item_parent', '34'),
(196, 41, '_menu_item_object_id', '41'),
(197, 41, '_menu_item_object', 'custom'),
(198, 41, '_menu_item_target', ''),
(199, 41, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(200, 41, '_menu_item_xfn', ''),
(201, 41, '_menu_item_url', ''),
(203, 42, '_menu_item_type', 'custom'),
(204, 42, '_menu_item_menu_item_parent', '34'),
(205, 42, '_menu_item_object_id', '42'),
(206, 42, '_menu_item_object', 'custom'),
(207, 42, '_menu_item_target', ''),
(208, 42, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(209, 42, '_menu_item_xfn', ''),
(210, 42, '_menu_item_url', 'http://s'),
(211, 44, '_edit_last', '1'),
(212, 44, '_edit_lock', '1494957918:1'),
(213, 44, '_wp_page_template', 'default'),
(214, 46, '_menu_item_type', 'post_type'),
(215, 46, '_menu_item_menu_item_parent', '34'),
(216, 46, '_menu_item_object_id', '44'),
(217, 46, '_menu_item_object', 'page'),
(218, 46, '_menu_item_target', ''),
(219, 46, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(220, 46, '_menu_item_xfn', ''),
(221, 46, '_menu_item_url', ''),
(223, 47, '_edit_last', '1'),
(224, 47, '_edit_lock', '1495039707:1'),
(225, 47, '_wp_page_template', 'page-blog.php'),
(226, 49, '_edit_last', '1'),
(227, 49, '_edit_lock', '1495044327:1'),
(230, 52, '_edit_last', '1'),
(231, 52, '_edit_lock', '1495044297:1'),
(233, 53, '_edit_last', '1'),
(234, 53, '_edit_lock', '1495044293:1'),
(239, 56, '_edit_last', '1'),
(240, 56, '_edit_lock', '1495044293:1'),
(242, 57, '_edit_last', '1'),
(243, 57, '_edit_lock', '1495044293:1'),
(245, 58, '_edit_last', '1'),
(246, 58, '_edit_lock', '1495044293:1'),
(247, 59, '_edit_last', '1'),
(248, 59, '_edit_lock', '1495125584:1'),
(249, 59, '_wp_trash_meta_status', 'draft'),
(250, 59, '_wp_trash_meta_time', '1495125629'),
(251, 59, '_wp_desired_post_slug', ''),
(252, 47, '_wp_trash_meta_status', 'publish'),
(253, 47, '_wp_trash_meta_time', '1495733170'),
(254, 47, '_wp_desired_post_slug', 'blog') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(4, 1, '2017-04-27 18:22:33', '2017-04-27 18:22:33', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2017-05-01 20:16:53', '2017-05-01 20:16:53', '', 0, 'http://shea-boyle.com/?page_id=4', 0, 'page', '', 0),
(5, 1, '2017-04-27 18:22:33', '2017-04-27 18:22:33', '', 'Welcome', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2017-04-27 18:22:33', '2017-04-27 18:22:33', '', 4, 'http://shea-boyle.com/2017/04/27/4-revision-v1/', 0, 'revision', '', 0),
(6, 1, '2017-04-27 18:22:48', '2017-04-27 18:22:48', '', 'Home', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2017-04-27 18:22:48', '2017-04-27 18:22:48', '', 4, 'http://shea-boyle.com/2017/04/27/4-revision-v1/', 0, 'revision', '', 0),
(9, 1, '2017-05-01 20:32:01', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-05-01 20:32:01', '0000-00-00 00:00:00', '', 0, 'http://shea-boyle.com/?p=9', 1, 'nav_menu_item', '', 0),
(10, 1, '2017-05-01 20:32:01', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-05-01 20:32:01', '0000-00-00 00:00:00', '', 0, 'http://shea-boyle.com/?p=10', 1, 'nav_menu_item', '', 0),
(11, 1, '2017-05-01 20:32:44', '2017-05-01 20:32:44', '', 'Attorneys', '', 'publish', 'closed', 'closed', '', 'attorneys', '', '', '2017-05-01 20:32:44', '2017-05-01 20:32:44', '', 0, 'http://shea-boyle.com/?page_id=11', 0, 'page', '', 0),
(12, 1, '2017-05-01 20:32:44', '2017-05-01 20:32:44', '', 'Attorneys', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2017-05-01 20:32:44', '2017-05-01 20:32:44', '', 11, 'http://shea-boyle.com/2017/05/01/11-revision-v1/', 0, 'revision', '', 0),
(13, 1, '2017-05-01 20:32:56', '2017-05-01 20:32:56', '', 'Brian Panish', '', 'publish', 'closed', 'closed', '', 'brian-panish', '', '', '2017-05-17 21:08:32', '2017-05-17 21:08:32', '', 0, 'http://shea-boyle.com/?page_id=13', 0, 'page', '', 0),
(14, 1, '2017-05-01 20:32:56', '2017-05-01 20:32:56', '', 'Brian Panish', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2017-05-01 20:32:56', '2017-05-01 20:32:56', '', 13, 'http://shea-boyle.com/2017/05/01/13-revision-v1/', 0, 'revision', '', 0),
(15, 1, '2017-05-01 20:33:09', '2017-05-01 20:33:09', '', 'Success Records', '', 'publish', 'closed', 'closed', '', 'success-records', '', '', '2017-05-18 21:51:09', '2017-05-18 21:51:09', '', 0, 'http://shea-boyle.com/?page_id=15', 0, 'page', '', 0),
(16, 1, '2017-05-01 20:33:09', '2017-05-01 20:33:09', '', 'Success Records', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2017-05-01 20:33:09', '2017-05-01 20:33:09', '', 15, 'http://shea-boyle.com/2017/05/01/15-revision-v1/', 0, 'revision', '', 0),
(17, 1, '2017-05-01 20:33:37', '2017-05-01 20:33:37', '', 'Airline Accidents', '', 'publish', 'closed', 'closed', '', 'airline-accidents', '', '', '2017-05-01 20:33:37', '2017-05-01 20:33:37', '', 0, 'http://shea-boyle.com/?page_id=17', 0, 'page', '', 0),
(18, 1, '2017-05-01 20:33:37', '2017-05-01 20:33:37', '', 'Airline Accidents', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2017-05-01 20:33:37', '2017-05-01 20:33:37', '', 17, 'http://shea-boyle.com/2017/05/01/17-revision-v1/', 0, 'revision', '', 0),
(19, 1, '2017-05-01 20:34:14', '2017-05-01 20:34:14', '', 'Practice Areas', '', 'publish', 'closed', 'closed', '', 'practice-areas', '', '', '2017-05-18 16:40:38', '2017-05-18 16:40:38', '', 0, 'http://shea-boyle.com/?page_id=19', 0, 'page', '', 0),
(20, 1, '2017-05-01 20:34:14', '2017-05-01 20:34:14', '', 'Practice Areas', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2017-05-01 20:34:14', '2017-05-01 20:34:14', '', 19, 'http://shea-boyle.com/2017/05/01/19-revision-v1/', 0, 'revision', '', 0),
(21, 1, '2017-05-01 20:34:26', '2017-05-01 20:34:26', '', 'News', '', 'publish', 'closed', 'closed', '', 'news', '', '', '2017-05-25 17:25:43', '2017-05-25 17:25:43', '', 0, 'http://shea-boyle.com/?page_id=21', 0, 'page', '', 0),
(22, 1, '2017-05-01 20:34:26', '2017-05-01 20:34:26', '', 'News', '', 'inherit', 'closed', 'closed', '', '21-revision-v1', '', '', '2017-05-01 20:34:26', '2017-05-01 20:34:26', '', 21, 'http://shea-boyle.com/2017/05/01/21-revision-v1/', 0, 'revision', '', 0),
(23, 1, '2017-05-01 20:34:34', '2017-05-01 20:34:34', '', 'Contact Us', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2017-05-18 21:27:47', '2017-05-18 21:27:47', '', 0, 'http://shea-boyle.com/?page_id=23', 0, 'page', '', 0),
(24, 1, '2017-05-01 20:34:34', '2017-05-01 20:34:34', '', 'Contact', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2017-05-01 20:34:34', '2017-05-01 20:34:34', '', 23, 'http://shea-boyle.com/2017/05/01/23-revision-v1/', 0, 'revision', '', 0),
(25, 1, '2017-05-01 20:34:39', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-05-01 20:34:39', '0000-00-00 00:00:00', '', 0, 'http://shea-boyle.com/?p=25', 1, 'nav_menu_item', '', 0),
(29, 1, '2017-05-01 20:36:08', '2017-05-01 20:36:08', '', 'Contact', '', 'publish', 'closed', 'closed', '', '29', '', '', '2017-05-18 17:45:33', '2017-05-18 17:45:33', '', 0, 'http://shea-boyle.com/?p=29', 12, 'nav_menu_item', '', 0),
(30, 1, '2017-05-01 20:36:08', '2017-05-01 20:36:08', ' ', '', '', 'publish', 'closed', 'closed', '', '30', '', '', '2017-05-18 17:45:33', '2017-05-18 17:45:33', '', 0, 'http://shea-boyle.com/?p=30', 1, 'nav_menu_item', '', 0),
(31, 1, '2017-05-01 20:36:08', '2017-05-01 20:36:08', ' ', '', '', 'publish', 'closed', 'closed', '', '31', '', '', '2017-05-18 17:45:33', '2017-05-18 17:45:33', '', 0, 'http://shea-boyle.com/?p=31', 11, 'nav_menu_item', '', 0),
(33, 1, '2017-05-01 20:36:08', '2017-05-01 20:36:08', ' ', '', '', 'publish', 'closed', 'closed', '', '33', '', '', '2017-05-18 17:45:33', '2017-05-18 17:45:33', '', 0, 'http://shea-boyle.com/?p=33', 7, 'nav_menu_item', '', 0),
(34, 1, '2017-05-01 20:36:08', '2017-05-01 20:36:08', '', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2017-05-18 17:45:33', '2017-05-18 17:45:33', '', 0, 'http://shea-boyle.com/?p=34', 2, 'nav_menu_item', '', 0),
(35, 1, '2017-05-01 20:40:27', '2017-05-01 20:40:27', '', 'See All Practice Areas', '', 'publish', 'closed', 'closed', '', 'see-all-practice-areas', '', '', '2017-05-18 17:45:33', '2017-05-18 17:45:33', '', 0, 'http://shea-boyle.com/?p=35', 10, 'nav_menu_item', '', 0),
(36, 1, '2017-05-01 20:40:27', '2017-05-01 20:40:27', ' ', '', '', 'publish', 'closed', 'closed', '', '36', '', '', '2017-05-18 17:45:33', '2017-05-18 17:45:33', '', 0, 'http://shea-boyle.com/?p=36', 3, 'nav_menu_item', '', 0),
(37, 1, '2017-05-01 20:40:27', '2017-05-01 20:40:27', '', 'Practice Areas', '', 'publish', 'closed', 'closed', '', 'practice-areas', '', '', '2017-05-18 17:45:33', '2017-05-18 17:45:33', '', 0, 'http://shea-boyle.com/?p=37', 8, 'nav_menu_item', '', 0),
(38, 1, '2017-05-01 20:37:57', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-05-01 20:37:57', '0000-00-00 00:00:00', '', 0, 'http://shea-boyle.com/?p=38', 1, 'nav_menu_item', '', 0),
(39, 1, '2017-05-01 20:37:57', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-05-01 20:37:57', '0000-00-00 00:00:00', '', 0, 'http://shea-boyle.com/?p=39', 1, 'nav_menu_item', '', 0),
(40, 1, '2017-05-01 20:40:27', '2017-05-01 20:40:27', ' ', '', '', 'publish', 'closed', 'closed', '', '40', '', '', '2017-05-18 17:45:33', '2017-05-18 17:45:33', '', 0, 'http://shea-boyle.com/?p=40', 9, 'nav_menu_item', '', 0),
(41, 1, '2017-05-01 23:31:46', '2017-05-01 23:31:46', '', 'test', '', 'publish', 'closed', 'closed', '', 'test', '', '', '2017-05-18 17:45:33', '2017-05-18 17:45:33', '', 0, 'http://shea-boyle.com/?p=41', 4, 'nav_menu_item', '', 0),
(42, 1, '2017-05-01 23:31:46', '2017-05-01 23:31:46', '', 'test2', '', 'publish', 'closed', 'closed', '', 'test2', '', '', '2017-05-18 17:45:33', '2017-05-18 17:45:33', '', 0, 'http://shea-boyle.com/?p=42', 5, 'nav_menu_item', '', 0),
(44, 1, '2017-05-16 18:07:37', '2017-05-16 18:07:37', '', 'Test Page', '', 'publish', 'closed', 'closed', '', 'test-page', '', '', '2017-05-16 18:07:37', '2017-05-16 18:07:37', '', 0, 'http://shea-boyle.com/?page_id=44', 0, 'page', '', 0),
(45, 1, '2017-05-16 18:07:37', '2017-05-16 18:07:37', '', 'Test Page', '', 'inherit', 'closed', 'closed', '', '44-revision-v1', '', '', '2017-05-16 18:07:37', '2017-05-16 18:07:37', '', 44, 'http://shea-boyle.com/2017/05/16/44-revision-v1/', 0, 'revision', '', 0),
(46, 1, '2017-05-16 18:07:57', '2017-05-16 18:07:57', ' ', '', '', 'publish', 'closed', 'closed', '', '46', '', '', '2017-05-18 17:45:33', '2017-05-18 17:45:33', '', 0, 'http://shea-boyle.com/?p=46', 6, 'nav_menu_item', '', 0),
(47, 1, '2017-05-17 16:49:17', '2017-05-17 16:49:17', '', 'Blog', '', 'trash', 'closed', 'closed', '', 'blog__trashed', '', '', '2017-05-25 17:26:10', '2017-05-25 17:26:10', '', 0, 'http://shea-boyle.com/?page_id=47', 0, 'page', '', 0),
(48, 1, '2017-05-17 16:49:17', '2017-05-17 16:49:17', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '47-revision-v1', '', '', '2017-05-17 16:49:17', '2017-05-17 16:49:17', '', 47, 'http://shea-boyle.com/2017/05/17/47-revision-v1/', 0, 'revision', '', 0),
(49, 1, '2017-05-17 17:08:25', '2017-05-17 17:08:25', 'If there is sub text make it look like this Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'Civil Trial for 2006 Robinson Helicopter Accident Begins', '', 'publish', 'open', 'open', '', 'civil-trial-for-2006-robinson-helicopter-accident-begins', '', '', '2017-05-17 18:05:26', '2017-05-17 18:05:26', '', 0, 'http://shea-boyle.com/?p=49', 0, 'post', '', 0),
(50, 1, '2017-05-17 17:08:25', '2017-05-17 17:08:25', 'If there is sub text make it look like this Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'Civil Trial for 2006 Robinson Helicopter Accident Begins', '', 'inherit', 'closed', 'closed', '', '49-revision-v1', '', '', '2017-05-17 17:08:25', '2017-05-17 17:08:25', '', 49, 'http://shea-boyle.com/2017/05/17/49-revision-v1/', 0, 'revision', '', 0),
(52, 1, '2017-05-17 17:51:15', '2017-05-17 17:51:15', 'If there is sub text make it look like this Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'Civil Trial for 2006 Robinson Helicopter Accident Begins  Copy', '', 'publish', 'open', 'open', '', 'civil-trial-for-2006-robinson-helicopter-accident-begins-copy', '', '', '2017-05-17 18:04:57', '2017-05-17 18:04:57', '', 0, 'http://shea-boyle.com/2017/05/17/civil-trial-for-2006-robinson-helicopter-accident-begins-copy/', 0, 'post', '', 0),
(53, 1, '2017-05-17 17:51:19', '2017-05-17 17:51:19', 'If there is sub text make it look like this Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'Civil Trial for 2006 Robinson Helicopter Accident Begins  Copy', '', 'publish', 'open', 'open', '', 'civil-trial-for-2006-robinson-helicopter-accident-begins-copy-2', '', '', '2017-05-17 18:04:53', '2017-05-17 18:04:53', '', 0, 'http://shea-boyle.com/2017/05/17/civil-trial-for-2006-robinson-helicopter-accident-begins-copy-2/', 0, 'post', '', 0),
(54, 1, '2017-05-17 18:04:53', '2017-05-17 18:04:53', 'If there is sub text make it look like this Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'Civil Trial for 2006 Robinson Helicopter Accident Begins  Copy', '', 'inherit', 'closed', 'closed', '', '53-revision-v1', '', '', '2017-05-17 18:04:53', '2017-05-17 18:04:53', '', 53, 'http://shea-boyle.com/2017/05/17/53-revision-v1/', 0, 'revision', '', 0),
(55, 1, '2017-05-17 18:04:57', '2017-05-17 18:04:57', 'If there is sub text make it look like this Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'Civil Trial for 2006 Robinson Helicopter Accident Begins  Copy', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2017-05-17 18:04:57', '2017-05-17 18:04:57', '', 52, 'http://shea-boyle.com/2017/05/17/52-revision-v1/', 0, 'revision', '', 0),
(56, 1, '2017-05-17 19:44:32', '2017-05-17 19:44:32', 'If there is sub text make it look like this Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'Civil Trial for 2006 Robinson Helicopter Accident Begins  Copy  Copy', '', 'publish', 'open', 'open', '', 'civil-trial-for-2006-robinson-helicopter-accident-begins-copy-2-copy', '', '', '2017-05-17 19:44:32', '2017-05-17 19:44:32', '', 0, 'http://shea-boyle.com/2017/05/17/civil-trial-for-2006-robinson-helicopter-accident-begins-copy-2-copy/', 0, 'post', '', 0),
(57, 1, '2017-05-17 19:44:37', '2017-05-17 19:44:37', 'If there is sub text make it look like this Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'Civil Trial for 2006 Robinson Helicopter Accident Begins  Copy  Copy  Copy', '', 'publish', 'open', 'open', '', 'civil-trial-for-2006-robinson-helicopter-accident-begins-copy-2-copy-copy', '', '', '2017-05-17 19:44:37', '2017-05-17 19:44:37', '', 0, 'http://shea-boyle.com/2017/05/17/civil-trial-for-2006-robinson-helicopter-accident-begins-copy-2-copy-copy/', 0, 'post', '', 0),
(58, 1, '2017-05-17 19:44:41', '2017-05-17 19:44:41', 'If there is sub text make it look like this Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'Civil Trial for 2006 Robinson Helicopter Accident Begins  Copy  Copy  Copy  Copy', '', 'publish', 'open', 'open', '', 'civil-trial-for-2006-robinson-helicopter-accident-begins-copy-2-copy-copy-copy', '', '', '2017-05-17 19:44:41', '2017-05-17 19:44:41', '', 0, 'http://shea-boyle.com/2017/05/17/civil-trial-for-2006-robinson-helicopter-accident-begins-copy-2-copy-copy-copy/', 0, 'post', '', 0),
(59, 1, '2017-05-18 16:39:44', '2017-05-18 16:39:44', '', 'Practice Areas', '', 'trash', 'closed', 'closed', '', '__trashed', '', '', '2017-05-18 16:40:29', '2017-05-18 16:40:29', '', 0, 'http://shea-boyle.com/?page_id=59', 0, 'page', '', 0),
(60, 1, '2017-05-18 16:40:29', '2017-05-18 16:40:29', '', 'Practice Areas', '', 'inherit', 'closed', 'closed', '', '59-revision-v1', '', '', '2017-05-18 16:40:29', '2017-05-18 16:40:29', '', 59, 'http://shea-boyle.com/2017/05/18/59-revision-v1/', 0, 'revision', '', 0),
(61, 1, '2017-05-18 17:45:14', '2017-05-18 17:45:14', '', 'Contact Us', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2017-05-18 17:45:14', '2017-05-18 17:45:14', '', 23, 'http://shea-boyle.com/2017/05/18/23-revision-v1/', 0, 'revision', '', 0),
(62, 1, '2017-05-25 20:14:25', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2017-05-25 20:14:25', '0000-00-00 00:00:00', '', 0, 'http://shea-boyle.com/?p=62', 0, 'post', '', 0),
(63, 1, '2017-05-30 22:48:56', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2017-05-30 22:48:56', '0000-00-00 00:00:00', '', 0, 'http://shea-boyle.com/?post_type=acf-field-group&p=63', 0, 'acf-field-group', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form`
#

DROP TABLE IF EXISTS `wp_rg_form`;


#
# Table structure of table `wp_rg_form`
#

CREATE TABLE `wp_rg_form` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `date_created` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_trash` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_form`
#
INSERT INTO `wp_rg_form` ( `id`, `title`, `date_created`, `is_active`, `is_trash`) VALUES
(1, 'Free Consultation', '2017-05-09 19:45:17', 1, 0) ;

#
# End of data contents of table `wp_rg_form`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form_meta`
#

DROP TABLE IF EXISTS `wp_rg_form_meta`;


#
# Table structure of table `wp_rg_form_meta`
#

CREATE TABLE `wp_rg_form_meta` (
  `form_id` mediumint(8) unsigned NOT NULL,
  `display_meta` longtext COLLATE utf8_unicode_ci,
  `entries_grid_meta` longtext COLLATE utf8_unicode_ci,
  `confirmations` longtext COLLATE utf8_unicode_ci,
  `notifications` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_form_meta`
#
INSERT INTO `wp_rg_form_meta` ( `form_id`, `display_meta`, `entries_grid_meta`, `confirmations`, `notifications`) VALUES
(1, '{"title":"Free Consultation","description":"","labelPlacement":"top_label","descriptionPlacement":"below","button":{"type":"text","text":"Submit","imageUrl":""},"fields":[{"type":"text","id":1,"label":"First Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"First Name","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1},{"type":"text","id":2,"label":"Last Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Last Name","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1},{"type":"phone","id":3,"label":"Number","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"phoneFormat":"standard","formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Number","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","form_id":"","productField":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1},{"type":"email","id":4,"label":"Email","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Email","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","emailConfirmEnabled":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1},{"type":"textarea","id":5,"label":"Describe Your Case","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Describe Your Case","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","form_id":"","useRichTextEditor":false,"multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"pageNumber":1}],"version":"2.2.2","id":1,"useCurrentUserAsAuthor":true,"postContentTemplateEnabled":false,"postTitleTemplateEnabled":false,"postTitleTemplate":"","postContentTemplate":"","lastPageButton":null,"pagination":null,"firstPageCssClass":null}', NULL, '{"59121c4dd8655":{"id":"59121c4dd8655","name":"Default Confirmation","isDefault":true,"type":"message","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":"","queryString":""}}', '{"59121c4dd5078":{"id":"59121c4dd5078","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}}') ;

#
# End of data contents of table `wp_rg_form_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form_view`
#

DROP TABLE IF EXISTS `wp_rg_form_view`;


#
# Table structure of table `wp_rg_form_view`
#

CREATE TABLE `wp_rg_form_view` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `count` mediumint(8) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_form_view`
#
INSERT INTO `wp_rg_form_view` ( `id`, `form_id`, `date_created`, `ip`, `count`) VALUES
(1, 1, '2017-05-09 19:47:52', '::1', 200),
(2, 1, '2017-05-10 19:55:33', '::1', 60),
(3, 1, '2017-05-10 19:55:33', '::1', 1),
(4, 1, '2017-05-11 20:56:13', '::1', 85),
(5, 1, '2017-05-12 21:16:34', '::1', 22),
(6, 1, '2017-05-15 15:24:03', '::1', 90),
(7, 1, '2017-05-16 15:48:00', '::1', 215),
(8, 1, '2017-05-17 15:57:04', '::1', 265),
(9, 1, '2017-05-18 16:07:54', '::1', 156),
(10, 1, '2017-05-19 16:08:47', '::1', 64),
(11, 1, '2017-05-22 15:14:28', '::1', 191),
(12, 1, '2017-05-23 15:55:30', '::1', 144),
(13, 1, '2017-05-24 16:02:55', '::1', 517),
(14, 1, '2017-05-25 16:03:59', '::1', 278),
(15, 1, '2017-05-26 16:47:46', '76.93.161.38', 40),
(16, 1, '2017-05-30 15:28:03', '::1', 58) ;

#
# End of data contents of table `wp_rg_form_view`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_incomplete_submissions`
#

DROP TABLE IF EXISTS `wp_rg_incomplete_submissions`;


#
# Table structure of table `wp_rg_incomplete_submissions`
#

CREATE TABLE `wp_rg_incomplete_submissions` (
  `uuid` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` varchar(39) COLLATE utf8_unicode_ci NOT NULL,
  `source_url` longtext COLLATE utf8_unicode_ci NOT NULL,
  `submission` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_incomplete_submissions`
#

#
# End of data contents of table `wp_rg_incomplete_submissions`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead`
#

DROP TABLE IF EXISTS `wp_rg_lead`;


#
# Table structure of table `wp_rg_lead`
#

CREATE TABLE `wp_rg_lead` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `is_starred` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `ip` varchar(39) COLLATE utf8_unicode_ci NOT NULL,
  `source_url` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_agent` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `currency` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_status` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_amount` decimal(19,2) DEFAULT NULL,
  `transaction_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_fulfilled` tinyint(1) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `transaction_type` tinyint(1) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `payment_method` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_lead`
#

#
# End of data contents of table `wp_rg_lead`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_detail`
#

DROP TABLE IF EXISTS `wp_rg_lead_detail`;


#
# Table structure of table `wp_rg_lead_detail`
#

CREATE TABLE `wp_rg_lead_detail` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `field_number` float NOT NULL,
  `value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_field_number` (`lead_id`,`field_number`),
  KEY `lead_field_value` (`value`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_lead_detail`
#

#
# End of data contents of table `wp_rg_lead_detail`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_detail_long`
#

DROP TABLE IF EXISTS `wp_rg_lead_detail_long`;


#
# Table structure of table `wp_rg_lead_detail_long`
#

CREATE TABLE `wp_rg_lead_detail_long` (
  `lead_detail_id` bigint(20) unsigned NOT NULL,
  `value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`lead_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_lead_detail_long`
#

#
# End of data contents of table `wp_rg_lead_detail_long`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_meta`
#

DROP TABLE IF EXISTS `wp_rg_lead_meta`;


#
# Table structure of table `wp_rg_lead_meta`
#

CREATE TABLE `wp_rg_lead_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lead_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_lead_meta`
#

#
# End of data contents of table `wp_rg_lead_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_notes`
#

DROP TABLE IF EXISTS `wp_rg_lead_notes`;


#
# Table structure of table `wp_rg_lead_notes`
#

CREATE TABLE `wp_rg_lead_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `user_name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `value` longtext COLLATE utf8_unicode_ci,
  `note_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_user_key` (`lead_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_lead_notes`
#

#
# End of data contents of table `wp_rg_lead_notes`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(29, 2, 0),
(30, 2, 0),
(31, 2, 0),
(33, 2, 0),
(34, 2, 0),
(35, 2, 0),
(36, 2, 0),
(37, 2, 0),
(40, 2, 0),
(41, 2, 0),
(42, 2, 0),
(46, 2, 0),
(49, 1, 0),
(49, 5, 0),
(52, 1, 0),
(52, 4, 0),
(53, 1, 0),
(53, 3, 0),
(56, 1, 0),
(56, 3, 0),
(57, 1, 0),
(57, 3, 0),
(58, 1, 0),
(58, 3, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 6),
(2, 2, 'nav_menu', '', 0, 12),
(3, 3, 'category', '', 0, 4),
(4, 4, 'category', '', 0, 1),
(5, 5, 'category', '', 0, 1) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Top Nav', 'top-nav', 0),
(3, 'Category 1', 'category-1', 0),
(4, 'Category 2', 'category-2', 0),
(5, 'Category 3', 'category-3', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'highrank'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'locale', ''),
(11, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(12, 1, 'wp_user_level', '10'),
(13, 1, 'dismissed_wp_pointers', ''),
(14, 1, 'show_welcome_panel', '1'),
(16, 1, 'wp_dashboard_quick_press_last_post_id', '62'),
(17, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(18, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(19, 1, 'nav_menu_recently_edited', '2'),
(20, 1, 'closedpostboxes_post', 'a:0:{}'),
(21, 1, 'metaboxhidden_post', 'a:5:{i:0;s:13:"trackbacksdiv";i:1;s:10:"postcustom";i:2;s:16:"commentstatusdiv";i:3;s:7:"slugdiv";i:4;s:9:"authordiv";}'),
(23, 1, 'session_tokens', 'a:1:{s:64:"1834bde1a0d69378d9fe18267e844203bbaf11e6032395cd7c104d1ea9923075";a:4:{s:10:"expiration";i:1496331213;s:2:"ip";s:3:"::1";s:2:"ua";s:82:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:53.0) Gecko/20100101 Firefox/53.0";s:5:"login";i:1496158413;}}'),
(24, 1, 'wp_yoast_notifications', 'a:4:{i:0;a:2:{s:7:"message";s:311:"The configuration wizard helps you to easily configure your site to have the optimal SEO settings.<br/>We have detected that you have not finished this wizard yet, so we recommend you to <a href="http://shea-boyle.com/wp-admin/?page=wpseo_configurator">start the configuration wizard to configure Yoast SEO</a>.";s:7:"options";a:8:{s:4:"type";s:7:"warning";s:2:"id";s:31:"wpseo-dismiss-onboarding-notice";s:5:"nonce";N;s:8:"priority";d:0.8000000000000000444089209850062616169452667236328125;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}i:1;a:2:{s:7:"message";s:770:"We\'ve noticed you\'ve been using Yoast SEO for some time now; we hope you love it! We\'d be thrilled if you could <a href="https://yoa.st/rate-yoast-seo?utm_content=4.8">give us a 5 stars rating on WordPress.org</a>!\n\nIf you are experiencing issues, <a href="https://yoa.st/bugreport?utm_content=4.8">please file a bug report</a> and we\'ll do our best to help you out.\n\nBy the way, did you know we also have a <a href=\'https://yoa.st/premium-notification?utm_content=4.8\'>Premium plugin</a>? It offers advanced features, like a redirect manager and support for multiple keywords. It also comes with 24/7 personal support.\n\n<a class="button" href="http://shea-boyle.com/wp-admin/?page=wpseo_dashboard&yoast_dismiss=upsell">Please don\'t show me this notification anymore</a>";s:7:"options";a:8:{s:4:"type";s:7:"warning";s:2:"id";s:19:"wpseo-upsell-notice";s:5:"nonce";N;s:8:"priority";d:0.8000000000000000444089209850062616169452667236328125;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}i:2;a:2:{s:7:"message";s:164:"Don\'t miss your crawl errors: <a href="http://shea-boyle.com/wp-admin/admin.php?page=wpseo_search_console&tab=settings">connect with Google Search Console here</a>.";s:7:"options";a:8:{s:4:"type";s:7:"warning";s:2:"id";s:17:"wpseo-dismiss-gsc";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}i:3;a:2:{s:7:"message";s:218:"<strong>Huge SEO Issue: You\'re blocking access to robots.</strong> You must <a href="http://shea-boyle.com/wp-admin/options-reading.php">go to your Reading Settings</a> and uncheck the box for Search Engine Visibility.";s:7:"options";a:8:{s:4:"type";s:5:"error";s:2:"id";s:32:"wpseo-dismiss-blog-public-notice";s:5:"nonce";N;s:8:"priority";i:1;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}}') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'highrank', '$P$B.7Alzi1qtqaft51AmsW/um/H7onH1.', 'highrank', 'garrett@1point21interactive.com', '', '2017-04-27 18:10:40', '', 0, 'highrank') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

